const axios = require('axios');
const fs = require('fs');
const path = require('path');
const { cmd } = require('../command'); // Assuming your command handler is here
// Imported but not explicitly used

// Utility function to fetch JSON responses
const fetchJson = async (url) => {
  try {
    const response = await axios.get(url);
    return response.data;
  } catch (error) {
    console.error("Error fetching JSON:", error);
    return null;
  }
};

// Command definition
cmd({
  pattern: "cinesubz",
  alias: ["cine"],
  react: "🎬",
  desc: "Search and download movies from CineSubz",
  category: "download",
  filename: __filename,
}, async (conn, m, mek, { from, q, senderNumber, reply }) => {
  try {
    // Step 1: Validate input query
    if (!q) {
      return await reply("*Please provide a movie name to search! (e.g., Avatar)*");
    }

    // Step 2: Search movies from CineSubz API
    const searchResponse = await fetchJson(
      `https://cinesubz-api-zazie.vercel.app/api/search?q=${encodeURIComponent(q)}`
    );

    if (!searchResponse || !searchResponse.status) {
      return await reply(`*No results found for:* "${q}"`);
    }

    const searchResults = searchResponse.result.data;
    let resultsMessage = `✨ *CINESUBZ DOWNLOADER* ✨\n\n🎥 *Search Results for* "${q}":\n\n`;

    searchResults.forEach((result, index) => {
      resultsMessage += `*${index + 1}.* ${result.title}\n`;
    });

    const sentMsg = await conn.sendMessage(
      from,
      { text: resultsMessage },
      { quoted: mek }
    );
    const messageID = sentMsg.key.id;

    // Step 3: Wait for the user to select a movie
    conn.ev.on("messages.upsert", async (messageUpdate) => {
      const replyMek = messageUpdate.messages[0];
      if (!replyMek.message) return;

      const messageType =
        replyMek.message.conversation ||
        replyMek.message.extendedTextMessage?.text;

      const isReplyToSentMsg =
        replyMek.message.extendedTextMessage &&
        replyMek.message.extendedTextMessage.contextInfo.stanzaId === messageID;

      if (isReplyToSentMsg) {
        const selectedNumber = parseInt(messageType.trim());
        if (!isNaN(selectedNumber) && selectedNumber > 0 && selectedNumber <= searchResults.length) {
          const selectedMovie = searchResults[selectedNumber - 1];

          // Step 4: Fetch movie download links
          const movieResponse = await fetchJson(
            `https://cinesubz-api-zazie.vercel.app/api/movie?url=${encodeURIComponent(
              selectedMovie.link
            )}`
          );

          if (!movieResponse || !movieResponse.status || !movieResponse.result.data.dl_links) {
            return await reply("*Error fetching download links for this movie.*");
          }

          const { title, imdbRate, image, date, country, director, duration, movie_link, thumbnail, dl_links } = movieResponse.result.data;

          if (dl_links.length === 0) {
            return await reply("*No download links available for this movie.*");
          }

          let downloadMessage = `🫧 _*ᴛɪᴛʟᴇ: ${title}*_\n\n\n`;
          downloadMessage += `🎛️ *ʀᴇʟᴇᴀꜱᴇ: ${date}*\n\n🌐 *ᴄᴏᴜɴᴛʀʏ: ${country}*\n\n⏱️ *ᴅᴜʀᴀᴛɪᴏɴ: ${duration}*\n\n🚀 *ɪᴍᴅʙ: ${imdbRate}*\n\n❄️ *ᴅɪʀᴇᴄᴛᴏʀ: ${director}*\n\n⚡ *ᴜʀʟ:* ${movie_link}\n\n*‼ ᴛᴇʟᴇɢʀᴀᴍ ʟɪɴᴋꜱ ɴᴏᴛ ᴀʟʟᴏᴡᴇᴅ... ᴅᴏɴ'ᴛ ᴜꜱᴇᴅ ᴛʜᴀᴛ 👀*\n\n`;
          downloadMessage += `🎗️ *ᴀᴠᴀɪʟᴀʙʟᴇ ᴍᴏᴠɪᴇ Qᴜᴀʟɪʏꜱ:*\n\n`;

          dl_links.forEach((link, index) => {
            downloadMessage += `> ${index + 1}. ${link.quality} [ ${link.size} ]\n`;
          });

          const sentDownloadMsg = await conn.sendMessage(from, {
            text: downloadMessage,
            contextInfo: {
              externalAdReply: {
                title: title,
                body: title,
                thumbnailUrl: thumbnail,
                sourceUrl: selectedMovie.link,
                mediaType: 1,
                renderLargerThumbnail: true,
              },
            },
          });

          const downloadMessageID = sentDownloadMsg.key.id;

          // Step 5: Wait for the user to select download quality
          conn.ev.on("messages.upsert", async (downloadUpdate) => {
            const downloadReply = downloadUpdate.messages[0];
            if (!downloadReply.message) return;

            const downloadMessageType =
              downloadReply.message.conversation ||
              downloadReply.message.extendedTextMessage?.text;

            const isReplyToDownloadMsg =
              downloadReply.message.extendedTextMessage &&
              downloadReply.message.extendedTextMessage.contextInfo.stanzaId === downloadMessageID;

            if (isReplyToDownloadMsg) {
              const selectedQuality = parseInt(downloadMessageType.trim());
              if (!isNaN(selectedQuality) && selectedQuality > 0 && selectedQuality <= dl_links.length) {
                const selectedLink = dl_links[selectedQuality - 1];

                // Step 6: Fetch the direct download link
                const movieLinkResponse = await fetchJson(
                  `https://cinesubz-api-zazie.vercel.app/api/links?url=${encodeURIComponent(
                    selectedLink.link
                  )}`
                );

                if (!movieLinkResponse || !movieLinkResponse.result.direct) {
                  return await reply("*Failed to fetch the direct download link.*");
                }
                await conn.sendMessage(from, { react: { text: "⬇️", key: downloadReply.key } });

                const downloadUrl = movieLinkResponse.result.direct;
                
                await conn.sendMessage(from, { react: { text: "⬆️", key: downloadReply.key } });
                // Send the video as a document
                await conn.sendMessage(from, {
                  document: { url: downloadUrl },
                  mimetype: "video/mp4",
                  fileName: `${title} - ${selectedLink.quality}.mp4`,
                  caption: `${title}\n\n${selectedLink.quality}\n\n> ＱＵＥＥＮＺＡＺＩＥ-ＭＤ-Ｖ3`,
                });

                await conn.sendMessage(from, { react: { text: "✔️", key: downloadReply.key } });
              } else {
                await reply("Invalid selection. Please reply with a valid number.");
              }
            }
          });
        } else {
          await reply("Invalid selection. Please reply with a valid number.");
        }
      }
    });
  } catch (e) {
    console.error("Error during CineSubz command execution:", e);
    reply("*An error occurred while processing your request.*");
  }
});
