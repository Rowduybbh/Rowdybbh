const config = require('../config');
const { cmd, commands } = require('../command');
const os = require("os");
const { runtime } = require('../lib/functions');

cmd({
    pattern: "menu",
    alias: ["list"],
    desc: "menu the bot",
    react: "📜",
    category: "main"
}, async (conn, mek, m, {
    from, quoted, body, isCmd, command, args, q, isGroup, sender, senderNumber, botNumber2, botNumber, pushname, isMe, isOwner, groupMetadata, groupName, participants, groupAdmins, isBotAdmins, isAdmins, reply
}) => {
    try {
        let desc = `👋 Hello ${pushname}

╭─「 ᴄᴏᴍᴍᴀɴᴅ ᴘᴀɴᴇʟ」
││◈ ʙᴏᴛ ɴᴀᴍᴇ : ʀᴏᴡᴅʏ-ᴍᴅ
││◈ ʀᴜɴᴛɪᴍᴇ : ${runtime(process.uptime())}
││◈ ʀᴀᴍ ᴜꜱᴀɢᴇ : ${(process.memoryUsage().heapUsed / 1024 / 1024).toFixed(2)}MB / ${Math.round(require('os').totalmem / 1024 / 1024)}MB
││◈ ᴘʟᴀᴛꜰᴏʀᴍ : ${os.hostname()}
││◈ ᴠᴇʀꜱɪᴏɴ : 1.0.0
╰─────────────◈

╭╼╼╼╼╼╼╼╼╼╼─◈
├ 1 • OWNER COMMANDS
├ 2 • CONVERT COMMANDS
├ 3 • AI COMMAND
├ 4 • SEARCH COMMANDS
├ 5 • DOWNLOAD COMMANDS
├ 6 • MAIN COMMANDS
├ 7 • GROUP COMMANDS
├ 8 • FUN COMMANDS
├ 9 • TOOLS COMMANDS
├ 10 • OTHER COMMANDS
╰╼╼╼╼╼╼╼╼╼╼────◈

🐼 Reply with the Number you want to select

> 𝐏𝐎𝐖𝐄𝐑𝐄𝐃 𝐁𝐘 𝐌𝐑 𝐃𝐀𝐊𝐒𝐇𝐈𝐍𝐀`;

        const vv = await conn.sendMessage(from, { image: { url: "https://i.ibb.co/zZ13BVL/9674.jpg" }, caption: desc }, { quoted: mek });

        conn.ev.on('messages.upsert', async (msgUpdate) => {
            const msg = msgUpdate.messages[0];
            if (!msg.message || !msg.message.extendedTextMessage) return;

            const selectedOption = msg.message.extendedTextMessage.text.trim();

            if (msg.message.extendedTextMessage.contextInfo && msg.message.extendedTextMessage.contextInfo.stanzaId === vv.key.id) {
                switch (selectedOption) {
                    case '1':
                        reply(`◈╾──────OWNER COMMAND LIST──────╼◈

╭────────◈
│ • restart 
╰────────────────────◈

⭓ Total Commands List OWNER: 1

> 𝐏𝐨𝐰𝐞𝐫𝐞𝐝 𝐛𝐲 𝐝𝐚𝐤𝐬𝐡𝐢𝐧𝐚`);
                        break;
                    case '2':
                        reply(`◈╾──────CONVERT COMMAND LIST──────╼◈

╭────────◈
│ • convert 
╰────────────────────◈

⭓ Total Commands List CONVERT: 1

> 𝐏𝐨𝐰𝐞𝐫𝐞𝐝 𝐛𝐲 𝐝𝐚𝐤𝐬𝐡𝐢𝐧𝐚`);
                        break;
                    case '3':
                        reply(`◈╾──────AI COMMAND LIST──────╼◈

╭────────◈
│ • ai 
╰────────────────────◈

⭓ Total Commands List AI: 1

> 𝐏𝐨𝐰𝐞𝐫𝐞𝐝 𝐛𝐲 𝐝𝐚𝐤𝐬𝐡𝐢𝐧𝐚`);
                        break;
                    case '4':
                        reply(`◈╾──────SEARCH COMMAND LIST──────╼◈

╭────────◈
│ • yts 
╰────────────────────◈
╭────────◈
│ • srepo 
╰────────────────────◈

⭓ Total Commands List SEARCH: 2

> 𝐏𝐨𝐰𝐞𝐫𝐞𝐝 𝐛𝐲 𝐝𝐚𝐤𝐬𝐡𝐢𝐧𝐚`);
                        break;
                    case '5':
                        reply(`◈╾──────DOWNLOAD COMMAND LIST──────╼◈

╭────────◈
│ • apk 
╰────────────────────◈
╭────────◈
│ • twitter 
╰────────────────────◈
╭────────◈
│ • gdrive 
╰────────────────────◈
╭────────◈
│ • mediafire 
╰────────────────────◈
╭────────◈
│ • fb 
╰────────────────────◈
╭────────◈
│ • ig 
╰────────────────────◈
╭────────◈
│ • movie 
╰────────────────────◈
╭────────◈
│ • song 
╰────────────────────◈
╭────────◈
│ • video 
╰────────────────────◈
╭────────◈
│ • play/yt 
╰────────────────────◈
╭────────◈
│ • song2 
╰────────────────────◈
╭────────◈
│ • video2 
╰────────────────────◈
╭────────◈
│ • tiktok 
╰────────────────────◈
╭────────◈
│ • img 
╰────────────────────◈

⭓ Total Commands List DOWNLOAD: 14

> 𝐏𝐨𝐰𝐞𝐫𝐞𝐝 𝐛𝐲 𝐝𝐚𝐤𝐬𝐡𝐢𝐧𝐚`);
                        break;
                    case '6':
                        reply(`◈╾──────MAIN COMMAND LIST──────╼◈

╭────────◈
│ • alive 
╰────────────────────◈
╭────────◈
│ • about 
╰────────────────────◈
╭────────◈
│ • menu 
╰────────────────────◈
╭────────◈
│ • allmenu 
╰────────────────────◈
╭────────◈
│ • support 
╰────────────────────◈
╭────────◈
│ • system 
╰────────────────────◈
╭────────◈
│ • ping 
╰────────────────────◈
╭────────◈
│ • runtime 
╰────────────────────◈

⭓ Total Commands List MAIN: 8

> 𝐏𝐨𝐰𝐞𝐫𝐞𝐝 𝐛𝐲 𝐝𝐚𝐤𝐬𝐡𝐢𝐧𝐚`);
                        break;
                    case '7':
                        reply(`◈╾──────GROUP COMMAND LIST──────╼◈

╭────────◈
│ • promote 
╰────────────────────◈
╭────────◈
│ • demote 
╰────────────────────◈
╭────────◈
│ • kick 
╰────────────────────◈
╭────────◈
│ • add 
╰────────────────────◈
╭────────◈
│ • admins 
╰────────────────────◈
╭────────◈
│ • tagall 
╰────────────────────◈
╭────────◈
│ • getpic 
╰────────────────────◈
╭────────◈
│ • setwelcome 
╰────────────────────◈
╭────────◈
│ • setgoodbye 
╰────────────────────◈
╭────────◈
│ • admins 
╰────────────────────◈
╭────────◈
│ • gname 
╰────────────────────◈

⭓ Total Commands List GROUP: 11

> 𝐏𝐨𝐰𝐞𝐫𝐞𝐝 𝐛𝐲 𝐝𝐚𝐤𝐬𝐡𝐢𝐧𝐚`);
                        break;
                    case '8':
                        reply(`◈╾──────FUN COMMAND LIST──────╼◈

╭────────◈
│ • dog 
╰────────────────────◈
╭────────◈
│ • fact 
╰────────────────────◈
╭────────◈
│ • hack 
╰────────────────────◈
╭────────◈
│ • quote 
╰────────────────────◈

⭓ Total Commands List FUN: 4

> 𝐏𝐨𝐰𝐞𝐫𝐞𝐝 𝐛𝐲 𝐝𝐚𝐤𝐬𝐡𝐢𝐧𝐚`);
                        break;
                    case '10':
                        reply(`◈╾──────OTHER COMMAND LIST──────╼◈

╭────────◈
│ • githubstalk 
╰────────────────────◈
╭────────◈
│ • trt 
╰────────────────────◈
╭────────◈
│ • weather 
╰────────────────────◈

⭓ Total Commands List OTHER: 3

> 𝐏𝐨𝐰𝐞𝐫𝐞𝐝 𝐛𝐲 𝐝𝐚𝐤𝐬𝐡𝐢𝐧𝐚`);
                        break;
                    default:
                        reply("❌ Invalid Option Selected!");
                }
            }
        });
    } catch (error) {
        conn.sendMessage(from, { react: { text: '❌', key: mek.key } });
        reply('An error occurred while processing your request.');
    }
});
