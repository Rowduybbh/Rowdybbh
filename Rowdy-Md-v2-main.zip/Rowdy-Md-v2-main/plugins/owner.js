const {cmd , commands} = require('../command')

cmd({
    pattern: "owner",
    desc: "owner the bot",
    category: "main",
    react: "👨‍💻",
    filename: __filename
},

async(conn, mek, m,{from, quoted, body, isCmd, command, args, q, isGroup, sender, senderNumber, botNumber2, botNumber, pushname, isMe, isOwner, groupMetadata, groupName, participants, groupAdmins, isBotAdmins, isAdmins, reply}) => {
try{

let dec = `👨‍💻 Rowdy Md Whatsapp Bot Owner 👨‍💻

╭───「 ᴏᴡɴᴇʀ ɪɴꜰᴏ 」
 | ᴏᴡɴᴇʀ ɴᴀᴍᴇ: Mr Dakshina
 | ᴡʜᴀᴛꜱᴀᴘᴘ ᴄʜᴀɴɴᴇʟ: https://whatsapp.com/channel/0029Vb30SSF3wtb1aK7ZGa3u
╰───────────────◈
𝐏𝐎𝐖𝐄𝐑𝐄𝐃 𝐁𝐘 𝐃𝐀𝐊𝐒𝐇𝐈𝐍𝐀
`
await conn.sendMessage(from,{image:{url: `https://i.ibb.co/zZ13BVL/9674.jpg` },caption:dec},{quoted:mek});
    const vcard = 'BEGIN:VCARD\n' // metadata of the contact card
            + 'VERSION:3.0\n' 
            + 'FN:Mr. dakshina\n'
            + 'ORG:Mr. dakshina\n'
            + 'TEL;type=CELL;type=VOICE;waid=94769615736:+94 76 961 5736\n'
            + 'EMAIL:dakshina@gmail.com\n'
            + 'END:VCARD';
                        await conn.sendMessage(from, { 
        contacts: { 
            displayName: 'Mr. Dakshina', 
            contacts: [{ vcard }] 
        }
    }
);

}catch(e){
console.log(e)
reply(`${e}`)
}
})
