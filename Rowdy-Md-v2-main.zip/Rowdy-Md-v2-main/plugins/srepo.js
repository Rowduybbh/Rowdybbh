const axios = require('axios');
const { cmd, commands } = require('../command');

cmd({
    pattern: "srepo",
    desc: "Fetch information about a GitHub repository.",
    category: "search",
    react: "📁",
    filename: __filename
},
async (conn, mek, m, { from, quoted, body, isCmd, command, args, q, isGroup, sender, senderNumber, botNumber2, botNumber, pushname, isMe, isOwner, groupMetadata, groupName, participants, groupAdmins, isBotAdmins, isAdmins, reply }) => {
    try {
        const repo = args.join(' ');
        if (!repo) {
            return reply("Please provide a GitHub repository name in the format `owner/repo`.");
        }

        const apiUrl = `https://api.github.com/repos/${repo}`;
        const response = await axios.get(apiUrl);
        const data = response.data;

        let repoInfo = `📁_GitHub Repository Info_📁\n\n`;
        repoInfo += `📌 Name: ${data.name}\n`;
        repoInfo += `🔗 URL: ${data.html_url}\n`;
        repoInfo += `📝 Description: ${data.description}\n`;
        repoInfo += `⭐ Stars: ${data.stargazers_count}\n`;
        repoInfo += `🍴 Forks: ${data.forks_count}\n`;
        repoInfo += `\n`;
        repoInfo += `> 𝐏𝐎𝐖𝐄𝐑𝐄𝐃 𝐁𝐘 𝐃𝐀𝐊𝐒𝐇𝐈𝐍𝐀 \n`;

        await conn.sendMessage(from, { text: repoInfo }, { quoted: mek });
    } catch (e) {
        console.log(e);
        reply(`єяяσя ƒєт¢нιηg яєρσѕιтσяу ιηƒσ: ${e.message}`);
    }
});
