const axios = require('axios');
const { cmd } = require('../command');

cmd({
    pattern: "phub",
    alias: ["pornhub"],
    react: "🫣",
    desc: "Search and download videos from Pornhub.",
    category: "nsfw",
    use: "phub <query>",
    filename: __filename,
}, async (conn, m, mek, { from, q, reply }) => {
    try {
        if (!q) return await reply("🚩 *Please provide a search term!*");

        const searchResults = await axios.get(`https://pornhub-apis-zazie.vercel.app/api/search?q=${q}`);
        const videos = searchResults.data?.data || [];
        if (videos.length === 0) {
            return await reply("🚩 *No results found! Please try another query.*");
        }

        const resultsMessage = videos
            .map((v, i) => `*${i + 1}.* *${v.title}*\n   ◦ *Duration:* ${v.duration}\n   ◦ *Uploader:* ${v.uploader}\n   ◦ *Link:* ${v.link}`)
            .join("\n\n");

        const sentMsg = await conn.sendMessage(from, { text: `乂 *PORNHUB SEARCH RESULTS* 乂\n\n${resultsMessage}\n\n*Reply with a number to choose a video!*` }, { quoted: mek });
        const messageID = sentMsg.key.id;

        conn.ev.on("messages.upsert", async (messageUpdate) => {
            const msg = messageUpdate.messages[0];
            if (!msg.message) return;

            const isReply = msg.message.extendedTextMessage?.contextInfo?.stanzaId === messageID;
            if (!isReply) return;

            const number = parseInt(msg.message.conversation || msg.message.extendedTextMessage?.text, 10) - 1;

            if (isNaN(number) || number < 0 || number >= videos.length) {
                return await conn.sendMessage(from, { text: "🚩 *Invalid number. Please reply with a valid number!*" }, { quoted: msg });
            }

            const selectedVideo = videos[number];
            await conn.sendMessage(from, { text: `🚩 *Fetching details for:* ${selectedVideo.title}` }, { quoted: msg });

            const videoDetails = await axios.get(`https://api-site-kappa.vercel.app/api/phdl?q=${selectedVideo.link}`);
            const videoData = videoDetails.data;
            const qualities = videoData?.dl_links || [];

            if (qualities.length === 0) {
                return await conn.sendMessage(from, { text: "🚩 *No qualities available for download.*" }, { quoted: msg });
            }

            const qualityMessage = qualities.map((q, i) => `*${i + 1}.* *Quality:* ${q.quality} - *Format:* ${q.file_type}`).join("\n");

            const qualityMsg = await conn.sendMessage(from, {
                image: { url: videoData.video_cover },
                caption: `乂 *PORNHUB VIDEO DETAILS* 乂\n\n*Title:* ${videoData.video_title}\n*Uploader:* ${videoData.video_uploader}\n*Uploaded on:* ${videoData.video_upload_date}\n\n🔸 *Available Qualities:*\n\n${qualityMessage}\n\n*Reply with a number to select a quality!*`
            }, { quoted: msg });
            const qualityMsgID = qualityMsg.key.id;

            conn.ev.on("messages.upsert", async (downloadUpdate) => {
                const downloadMsg = downloadUpdate.messages[0];
                if (!downloadMsg.message) return;

                const isQualityReply = downloadMsg.message.extendedTextMessage?.contextInfo?.stanzaId === qualityMsgID;
                if (!isQualityReply) return;

                const qualityNumber = parseInt(downloadMsg.message.conversation || downloadMsg.message.extendedTextMessage?.text, 10) - 1;

                if (isNaN(qualityNumber) || qualityNumber < 0 || qualityNumber >= qualities.length) {
                    return await conn.sendMessage(from, { text: "🚩 *Invalid number. Please reply with a valid number!*" }, { quoted: downloadMsg });
                }
                await conn.sendMessage(from, { react: { text: "⬇️", key: downloadMsg.key } });
                await conn.sendMessage(from, { react: { text: "⬆️", key: downloadMsg.key } });

                const selectedQuality = qualities[qualityNumber];
                await conn.sendMessage(from, {
                    document: { url: selectedQuality.download_url },
                    mimetype: 'video/mp4',
                    fileName: `${videoData.video_title} - ${selectedQuality.quality}.mp4`,
                    jpegThumbnail: (await axios({ url: videoData.video_cover, responseType: 'arraybuffer' })).data,
                    caption: `> ${videoData.video_title}`
                }, { quoted: downloadMsg });
                
                await conn.sendMessage(from, { react: { text: "✔️", key: downloadMsg.key } });
            });
        });
    } catch (error) {
        console.error('Error in command:', error);
        await reply("🚩 *An error occurred while processing your request!*");
    }
});
